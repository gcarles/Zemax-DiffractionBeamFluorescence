% This file loads a grid from a file that contains the (complex) electric
% field values at a specified regular grid, i.e. xy plane.
% Uses the beam propagation method to propagate the electric field towards
% the z direction.
% Optionally, a fractal model of the refractive index of the medium can be
% calculated to simulate scattering in the propagation.
% Additionally a model of a sample defined through a STL file is imported
% The volume over which the electric field is calculated is voxelised.
% The voxels that are inside the sample volume are considered to fluoresce.
% The relative intensity of the fluorescence of all the fluorescent voxels
% is stored into a file.

% The output file may be used in Zemax by SourceFromDB.dll
% The input electric field may be calculated in Zemax by calculating the
% Angular Spectrum representation of a beam using AngSpectrumCalc.dll

% (c) Guillem Carles (guillemcarles@gmail.com)
% Citation: 'in preparation'

% Acknowledgments:
% Information on calculation of the fractal model of refraction index:
% [Glaser et al, Optica 3, 861-869 (2016)]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Input parameters and data:

% Folder where to store the results:
output_folder='output';
% Base filename of the results files:
output_name='intensity_map_num'; % 'intensity_map_num' is the name that SourceFromDB.dll will read from disk.

% Load the electric field at the initial plane:
% (calculated e.g. from Zemax using AngSpectrumCalc.DLL)
aaa=dlmread('input\EfieldGrid.txt',';');

% Name of the STL model to load as sample
sampleSTLname='input\neuron3.stl'; % Adapted from: "Neuron by ewolfy, Published on October 12 (2012), www.thingiverse.com/thing:32309 (Creative Commons - Attribution - Share Alike)"

% Threshold for the intensity to consider fluorescence
intensThresh=0.001; % threshold, with respect to maximum value

% Calculate scattering in the medium or not
scatteringON = true;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


addpath Mesh_voxelisation % Folder with Matlab files for voxelisation
addpath Corr3Dfunction

% Resample the electric field and xy coordinates:
efield = imresize(aaa(2:end,2:2:end),[1001 1001]) + imresize(aaa(2:end,3:2:end),[1001 1001])*1i;
x1 = linspace(aaa(1,2),aaa(1,end-1),1001);
y1 = linspace(aaa(2,1),aaa(end,1),1001);
% Calculate the intensity at the initial plane
intfield=efield.*conj(efield);

% Calculate parameters for fractal scattering if pertinent
if scatteringON
    % Fractal model of refractive index [see ref]
    x=x1/1000; %x in microns
    y=y1/1000; %y in microns
    nrz=501;% Number of z steps
    z=linspace(0,200e-6,nrz); % z in microns
    dx=(x(2)-x(1));
    dy=(y(2)-y(1));
    dz=(z(2)-z(1));
    nrx=length(x);
    nry=length(y);
    kxmax = 2*pi/dx;
    dkx = kxmax/nrx;
    kx = -(kxmax*(nrx-1)/nrx/2) : dkx : (kxmax*(nrx-1)/nrx/2);
    kymax = 2*pi/dy;
    dky = kymax/nry;
    ky = -(kymax*(nry-1)/nry/2) : dky : (kymax*(nry-1)/nry/2);
    [kyy,kxx]=meshgrid(kx,ky);
    krr=sqrt(kxx.^2+kyy.^2);
    lambda=488e-9;
    n0=1;
    k0=2*pi/lambda;
    dn=8e-7; % variance of refractive index
    Df=3.6666666667; % fractal dimension
    lmax=0.0000040000; % correlation length [m]
    muabs=log(100)*1000; % Absorption coefficient of the medium
    muabs_sample=log(100)*100000; %Absorption coefficient of the sample
    kz=sqrt((k0.*n0).^2-krr.^2);
    [xx,yy]=meshgrid(x,y);
    rr=sqrt(xx.^2+yy.^2);
    % Guard Band
    guard=ones(nry,nrx);
    guard((k0.*n0).^2<krr.^2)=0; % Added to disallow non-physical values
    
    disp('Calculating the 3D correlation...');
    [S]=generate_corr_3D(dn,lmax/dx,Df,nry,nrx,nrz);
    Sini=single(S(1:nry,1:nrx,1:nrz));
    clear S;
    % Save the correlated function:
    save([output_folder '\correlated3D.mat'],'Sini');
end

% Calculate beam without sample (used to extract the max value)
% Start with imported electric field
fz=conj(efield);
Output = single(zeros(nry,nrx,nrz));
Output(:,:,1) = single(abs(fz).^2);
Fz=ifftshift(ifft2(ifftshift(fz)));
%D=exp(1i*(krr.^2)./(2*k0*n0)*dz); %this would be paraxial (GC)
%D=exp(-1i.*kz.*dz);
D=exp(-1i.*kz.*dz).*exp(-muabs/2*dz); % includes absorption (/2 as absorption is defined for intensity not electric field)
Fz_D=Fz.*D;
fz=fftshift(fft2(fftshift(Fz_D.*guard)));
tic;
disp('Propagating the beam...');
for itr=1:nrz-1
    if scatteringON
        N=Sini(:,:,itr);
        fz=fz.*exp(-1i*N*k0*dz);
    end
    Fz=ifftshift(ifft2(ifftshift(fz)));
    Fz_D=Fz.*D;
    fz=fftshift(fft2(fftshift(Fz_D.*guard)));
    Output(:,:,itr+1)=single(abs(fz).^2);
end
disp('Done (first)');
toc;

% Write out a tiff stack for the beam:
maxim=max(Output(:))*1.1; % use a slightly higher normalisation maximum as scattering might vary the peak maximum
for iiz=1:10:nrz
    if iiz==1
        imwrite(im2uint8(Output(:,:,iiz)/maxim),[output_folder '\illumination_lightsheet_nosample.TIFF']);
    else
        imwrite(im2uint8(Output(:,:,iiz)/maxim),[output_folder '\illumination_lightsheet_nosample.TIFF'],'writemode','append');
    end
end


% Voxelise the volume with sample
z1=(z-100e-6)*1000; %in mm
[stlcoords1] = READ_stl(sampleSTLname); % N by xyz by vertex

% Apply geometrical transformations to the sample (if required)
% (move the sample and rotate by 180deg)
stlcoords=stlcoords1;
stlcoords(:,3,:)=-stlcoords1(:,3,:)+0.0075/5e-4;
stlcoords(:,2,:)=-stlcoords1(:,2,:);

% Calculate the voxelised 3d grid
tic;
disp('Voxelising the sample volume...');
OUTPUTgrid_sparse=sparse(nrx*nry,nrz);
zgrups=200; % split in groups of e.g. 200 to not run out of memory.
for iiz=1:zgrups:(nrz-zgrups-2) % because VOXELISE needs at least two z values.
    OUTPUTgrid = VOXELISE(x1,y1,z1(iiz:(iiz+zgrups-1)),stlcoords*5e-4,'xyz');
    for jjz=1:zgrups
        aux1=squeeze(OUTPUTgrid(:,:,jjz));
        OUTPUTgrid_sparse(aux1(:),iiz+jjz-1)=true;
    end
end
iiz2=(iiz+zgrups):nrz; % we do the rest - at least two.
OUTPUTgrid = VOXELISE(x1,y1,z1(iiz2),stlcoords*5e-4,'xyz');
for jjz=1:length(iiz2)
    aux1=squeeze(OUTPUTgrid(:,:,jjz));
    OUTPUTgrid_sparse(aux1(:),iiz2(jjz))=true;
end
toc;

% scan the sample in y and calculate the beam in each case
ystep=0:300;
yscans=-0.03+ystep/300*0.06;
totals=zeros(1,length(yscans));
NNs=zeros(1,length(yscans));
for ii=1:length(yscans)
    tic;
    % Move the sample by shifting the voxelised grid:
    nn=round(yscans(ii)/1000/dy); % dy is in meters...
    OUTPUTgrid_sparse_shifted = circshift(OUTPUTgrid_sparse,[nn*nrx 0]);
    
    % Move the medium (if pertinent) to simulate scanning
    Smoved = circshift(Sini,[0 nn 0]);
    
    % Start with imported electric field
    fz=conj(efield);
    clear Output;
    Output = single(zeros(nry,nrx,nrz));
    Output(:,:,1) = single(abs(fz).^2);
    Fz=ifftshift(ifft2(ifftshift(fz)));
    Fz_D=Fz.*D;
    fz=fftshift(fft2(fftshift(Fz_D.*guard)));
    disp('Propagating the beam...');
    for itr=1:nrz-1
        if scatteringON
            N=Smoved(:,:,itr);
            fz=fz.*exp(-1i*N*k0*dz);
        end
        Fz=ifftshift(ifft2(ifftshift(fz)));
        Fz_D=Fz.*D;
        fz=fftshift(fft2(fftshift(Fz_D.*guard)));
        % Find grid positions that are inside the sample:
        gridsample = full(reshape(OUTPUTgrid_sparse_shifted(:,itr) + OUTPUTgrid_sparse_shifted(:,itr+1),[nrx nry]))'; % had x on rows, and want x on cols now
        transgrid = exp(-gridsample*(muabs_sample-muabs)*dz/4); % add the absorption of the sample (minus the medium which is accounted in D). gridsample is the sum/2 such that it accounts for half sample half medium.
        fz=fz.*transgrid;
        % Add refraction effects if required here...
        Output(:,:,itr+1)=single(abs(fz).^2);
    end
    
    % Write out a tiff stack for the beam:
    disp('Writing light sheet TIFF');
    if max(Output(:))>maxim, warning(['Peak intensity over set maximum: max = ' num2str(maxim) ' and max(Output) = ' num2str(max(Output(:)))]); end
    for iiz=1:10:nrz
        if iiz==1
            imwrite(im2uint8(imresize(Output(:,:,iiz)/maxim,[512 512])),[output_folder '\illumination_lightsheet_num' num2str(ii-1,'%05d') '.TIFF']);
        else
            imwrite(im2uint8(imresize(Output(:,:,iiz)/maxim,[512 512])),[output_folder '\illumination_lightsheet_num' num2str(ii-1,'%05d') '.TIFF'],'writemode','append');
        end
    end
    
    % Build the fluorescence table
    disp('Writing intensity map');
    % Swap x-y and move the sample
    aux=find(OUTPUTgrid_sparse==1);
    [xi,yi,zi] = ind2sub([nrx nry nrz],aux);
    yi=yi+nn; % move sample
    indi = sub2ind([nrx nry nrz],yi,xi,zi);
    inti=double(Output(indi));

    % Threshold by intensity
    INTthresh=inti>=maxim*intensThresh;
    xith=xi(INTthresh);
    yith=yi(INTthresh);
    zith=zi(INTthresh);
    intith=inti(INTthresh);
    
    % Total intensity
    total = sum(intith);
    totals(ii)=total;
    NNs(ii)=length(intith);
    
    % Cummulative sum of the intensity over voxels
    cumint = cumsum(intith);
    
    % Values to store to disk
    store = [x1(xith)', y1(yith)', z1(zith)', cumint/total];
    fileID = fopen([output_folder '\' output_name num2str(ii-1,'%05d') '.txt'],'w');
    fprintf(fileID,'%7d %17.12e\r\n',NNs(ii),total);
    fprintf(fileID,'%13.10f %13.10f %13.10f %20.17f\r\n',store');
    fclose(fileID);
    disp(['Done ' num2str(ii) ' (with ' num2str(NNs(ii)) ' elements)']);
    disp(['Done ( ' num2str(ii) ' / ' num2str(length(yscans)) ' )']);
    toc;
end





