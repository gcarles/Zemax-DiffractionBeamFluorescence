%       function final_waveform = generate_corr_3D(An,nc,D,S,rng_seed)
%
%       Description:
%       Generates a three-dimensional (3-D) zero-mean real correlated array x[a,b,c].
%
%       Inputs:
%       An = is the fluctuation strength
%       nc = the correlation length in grid cells : nc = Ln/dx, where dx is the
%        spatial increment, and lc is the correlation length in the continuous-domain
%        correlation function.
%       S = Number of pixels per side
%       D = Shape parameter of the whittle mattern correlation function
%       rng_seed = A seed number for the random number generator. Can be any nonnegative integer seed less than 2^32
%
%       The correlation function is given by
%       Bn[x,y,z]=Bn[r]=An*(r/nc)^((D-3)/2)*BesselK((D-3)/2,r/nc)
%       Here, r = (x^2+y^2+z^2)^1/2. The correlation function is circularly symmetric
%       in the (x,y) space.
%
%       Outputs:
%       final_waveform = a 3D rendering of the medium specified by the input
%       parameters
%
%       Notes:
%       To avoid aliasing in the spatial-frequency domain, nc>>(1/pi) must be satisfied,
%       To avoid aliasing in the spatial domain, (S/nc)>>1
%       Copyright (C) 2012  Ilker R. Capoglu
%       Modified by Andrew J. Radosevich 12/12/2012
%       Modified by Guillem Carles 06/04/2018
%
%       Example:
%       final_waveform = generate_corr_3D(1,5,3,100,1);
function [final_waveform, Phis, kx] = generate_corr_3D(dn,nc,D,Sx,Sy,Sz,rng_seed)

An=dn*2^((5-D)/2)/abs(gamma((D-3)/2));

if mod(Sx,2);
   Sx = Sx+1; 
end
if mod(Sy,2);
   Sy = Sy+1; 
end
if mod(Sz,2);
   Sz = Sz+1; 
end

if nargin ~= 7;
    rng('shuffle');% seed the random number generator
elseif nargin == 7;
    rng(rng_seed);% seed according to given value
end

% these are "fftshift"ed ranges, which will be later reversed
% for even length L, zero freq. is at L/2+1
% for odd length L, zero freq. is at (L+1)/2
kx = 2*pi/Sx*[-floor(Sx/2):floor((Sx-1)/2)];
ky = 2*pi/Sy*[-floor(Sy/2):floor((Sy-1)/2)];
kz = 2*pi/Sz*[-floor(Sz/2):floor((Sz-1)/2)];

[Kx,Ky,Kz] = ndgrid(kx,ky,kz);
Ksquared = Kx.^2+Ky.^2+Kz.^2;clear Kx Ky Kz;

Phis=An*nc^3*gamma(D/2)/pi^(3/2)/2^((5-D)/2)*(1+Ksquared*nc^2).^(-D/2);

sample_waveform = ifftn(ifftshift( ...
    randn(size(Ksquared)).*...%gaussian white noise with variance of 1.
    sqrt(Phis))).* ...%sqrt of 2D transform of Bn(r)
    sqrt(numel(Ksquared)*(2*pi)^ndims(Ksquared)) ;%normalization factor

% Add real and imaginary parts to get non-symmetric full array:
final_waveform=real(sample_waveform)+imag(sample_waveform);